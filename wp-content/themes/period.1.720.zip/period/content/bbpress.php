<div class='entry'>
	<div class='post-header'>
		<h1 class='post-title'><?php the_title(); ?></h1>
	</div>
	<div class='post-content'>
		<article>
			<?php the_content(); ?>
		</article>
	</div>
</div>