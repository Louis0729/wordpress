<nav class="further-reading">
	<div class="previous">
		<?php previous_image_link( false, esc_html__( 'Previous Image', 'period' ) ); ?>
	</div>
	<div class="next">
		<?php next_image_link( false, esc_html__( 'Next Image', 'period' ) ); ?>
	</div>
</nav>